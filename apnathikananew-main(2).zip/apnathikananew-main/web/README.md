# Apna Thikana — Web (Vite + React + Tailwind)

Run:
```bash
npm install
npm run dev
# http://localhost:5173
```
The dev server proxies `/api` to the backend at `http://localhost:4000`.
Set env `VITE_RAZORPAY_KEY_ID` in a `.env` for your key (optional).